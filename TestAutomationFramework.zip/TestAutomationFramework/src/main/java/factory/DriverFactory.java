package factory;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class DriverFactory {

    public WebDriver initializationDriver()

    {
        WebDriverManager.chromedriver ().setup ();
        WebDriver driver = new ChromeDriver ();
        driver.manage ().timeouts ().implicitlyWait ( 50 , TimeUnit.SECONDS );
        driver.manage ().window ().maximize ();
        driver.navigate ().to ( "https://demo.nopcommerce.com/" );

        return driver;
    }
}
