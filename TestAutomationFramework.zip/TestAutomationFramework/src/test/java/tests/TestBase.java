package tests;

import factory.DriverFactory;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import utilities.Helper;

import java.util.concurrent.TimeUnit;

public class TestBase
{

    public static WebDriver driver;

    @BeforeSuite
    public void setDriver() {
    driver = new DriverFactory ().initializationDriver ();
    }

    @AfterSuite
    public void stopDriver()
    {
        driver.quit ();
    }
    //take a screenshot when testcase fail and add it in the Screen shot folder
    @AfterMethod

    public void screenshotOnFailure(ITestResult result)
    {
        if (result.getStatus () == ITestResult.FAILURE)
        {
            System.out.println ("Failed");
            System.out.println ("Taking Screenshot......");
            Helper.captureScreeshot ( driver, result.getName () );
        }
    }
}
