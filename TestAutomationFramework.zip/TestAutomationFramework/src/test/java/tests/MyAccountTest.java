package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.MyAccountPage;
import pages.UserRegistrationPage;

public class MyAccountTest extends TestBase{

    HomePage homeObject ;
    UserRegistrationPage registerObject ;
    LoginPage loginObject ;

    MyAccountPage myAccountObject;

    String firstName ="Reham";
    String lastName= "Eid";
    String email= "Test10@Testing.com";
    String password = "123456789";
    String newPassword = "12345678";

    @Test(priority=1,alwaysRun=true)
    public void UserCanRegisterSuccssfully()
    {
        homeObject = new HomePage(driver);
        homeObject.openRegistrationPage();
        registerObject = new UserRegistrationPage(driver);
        registerObject.userRegistration(firstName, lastName, email, password);
        Assert.assertTrue(registerObject.successMessage.getText().contains("Your registration completed"));
    }

    @Test(priority = 2)
    public void RegisteredUserCanLogin()
    {
        registerObject = new UserRegistrationPage ( driver );
        registerObject.openLoginPage();
        loginObject = new LoginPage(driver);
        loginObject.userLogin (email, password);
    }


    @Test (priority = 3)
    public void changePassword()
    {
        loginObject = new LoginPage(driver);
        loginObject.openMyAccountPage ();
        myAccountObject= new MyAccountPage ( driver );
        myAccountObject.openChangePasswordPage();
        myAccountObject.changePassword ( password , newPassword);
        Assert.assertTrue ( myAccountObject.message.getText ().contains ( "Password was changed" ) );
        myAccountObject.setCloseMessage ();
    }


    @Test (priority = 4)
    public void userLogoutAfterChangeHisPassword()
    {
        myAccountObject = new MyAccountPage ( driver );
        myAccountObject.userLogout ();
    }
}
